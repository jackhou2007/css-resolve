define(function () {
  return {
    getHello: function () {
      return 'Hello World';
    }
  };
});
